import React from "react";

function Dashboard() {
  return (
    <div className="container-fluid">
      <div className="card shadow border-0 mb-7 minHeight align-items-center justify-content-center">
        <h2>Comming Soon ....</h2>
      </div>
    </div>
  );
}

export default Dashboard;
