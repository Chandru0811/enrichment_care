import React from "react";
import Sidebar from "../components/common/Sidebar";
import Home from "../pages/Home";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "../pages/Dashboard";
import Footer from "../components/common/Footer";
import Center from "../pages/Center/Center";
import CenterAdd from "../pages/Center/CenterAdd";
import CenterView from "../pages/Center/CenterView";
import CenterEdit from "../pages/Center/CenterEdit";
import Course from "../pages/Course/Course";
import CourseAdd from "../pages/Course/CourseAdd";
import CourseEdit from "../pages/Course/CourseEdit";
import CourseView from "../pages/Course/CourseView";
// import Curriculum from "../pages/Course/curriculum";
import Level from "../pages/Level/Level";
import LevelAdd from "../pages/Level/LevelAdd";
import LevelEdit from "../pages/Level/LevelEdit";
import LevelView from "../pages/Level/LevelView";
import Subject from "../pages/Subject/Subject";
import SubjectAdd from "../pages/Subject/SubjectAdd";
import SubjectEdit from "../pages/Subject/SubjectEdit";
import SubjectView from "../pages/Subject/SubjectView";
import Class from "../pages/Class/Class";
import ClassAdd from "../pages/Class/ClassAdd";
import ClassEdit from "../pages/Class/ClassEdit";
import ClassView from "../pages/Class/ClassView";
import Lead from "../pages/Lead/Lead";
import EnrollmentAdd from "../pages/Lead/Enrollment/EnrollmentAdd";
import EnrollmentEdit from "../pages/Lead/Enrollment/EnrollmentEdit";
import LeadView from "../pages/Lead/LeadView";

function Admin({ handleLogout }) {
  return (
    <BrowserRouter>
      <div className="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
        <Sidebar onLogout={handleLogout} />
        <div className="h-screen flex-grow-1 overflow-y-lg-auto">
          <main className="py-6 bg-surface-secondary">
            <Routes>
              <Route path="/center" element={<Center />} />
              <Route path="/center/add" element={<CenterAdd />} />
              <Route path="/center/view" element={<CenterView />} />
              <Route path="/center/edit" element={<CenterEdit />} />

              <Route path="/course" element={<Course />} />
              <Route path="/course/add" element={<CourseAdd />} />
              <Route path="/course/edit" element={<CourseEdit />} />
              <Route path="/course/view" element={<CourseView />} />
              {/* <Route path="/course/curriculum/:id" element={<Curriculum />} />
              <Route path="/curriculum" element={<Curriculum />} /> */}

              <Route path="/level" element={<Level />} />
              <Route path="/level/add" element={<LevelAdd />} />
              <Route path="/level/edit" element={<LevelEdit />} />
              <Route path="/level/view" element={<LevelView />} />

              <Route path="/subject" element={<Subject />} />
              <Route path="/subject/add" element={<SubjectAdd />} />
              <Route path="/subject/edit" element={<SubjectEdit />} />
              <Route path="/subject/view" element={<SubjectView />} />

              <Route path="/class" element={<Class />} />
              <Route path="/class/add" element={<ClassAdd />} />
              <Route path="/class/edit" element={<ClassEdit />} />
              <Route path="/class/view" element={<ClassView />} />

              <Route path="/lead/lead" element={<Lead />} />
              <Route path="/lead/lead/add" element={<EnrollmentAdd />} />
              <Route path="/lead/lead/edit" element={<EnrollmentEdit />} />
              <Route path="/lead/lead/view" element={<LeadView />} />
              
            </Routes>

            <Footer />
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default Admin;
